// window.alert("ahmed")
// document.getElementById("demo").innerHTML=("hello fegoo");

// console.log("figo")
// var userName = "ahmed";
// console.log(typeof(userName))
// var userName = window.prompt("enter name");
// console.log(userName)
// var userName="10"
// if (userName<"20"){
//     console.log("hello fego")
// }
// else{
//     console.log("hello mego")

// }
// for(var i=5;i<=10;i+=1){
// console.log(i)

// }
// var cartona=""
// for( var i=5 ; i<100 ; i++ ){
//     cartona+="<li>ahmed</li>"
// }
// document.getElementById("demo").innerHTML+=cartona
// var cart="";
// for (var i=1990;i<=2024;i++ ){
//     cart+="<option >"+i+"</option>";

// }
 // console.log(cart)
// document.getElementById("demo").innerHTML+=cart

// var cart ="";
// for(i=1900;i<=2024;i++){
//     cart+="<option>"+i+"</option>"
// }
// document.getElementById("demo").innerHTML+=cart;
// function sum(x,y){
//         var num1 =x;
//         var num2 =y;
//         var result = num1+num2;
//         console.log(result)
// }




// sum(5,10);
// sum(50,10);
// sum(5,100);
// sum(55,100);
// sum(5,110);
// function sum(x,y){
//     var num1 =x;
//     var num2 =y;
//     var result = ((num1+num2)/2);
//     console.log(result)
// }

// sum(6,4);

// function fsum (x,y){
//             var num1 = x ;
//             var num2 = y;
//           var  result= num1+num2;
//             return  result
//             ;
//         }

//   var x=    fsum(10,20);
// console.log (x);

// function averge (x){
//     var ave = (x/2)
//     console.log(ave)}

//     averge(x)
// (function(){




// })()
// var ahmed =12
// console.log(ahmed);
// var product = {
//     name:"tv",
//     price:100,
//     salle : true,
// };
// console.log(product)
// prompt("aaa")
// array
// var friends = ["ahmed" , "mohamed" , "doda" ]
// for(var i = 0;i<friends.length;i++){
//     console.log(friends[i])

// }
// var num= Math.floor(Math.random()*num.length)




// task 2
function quote (){
    var name =["--Oscar Wilde"  , "--Frank Zappa" ,  "--Elbert Hubbard" ,"--Mark Twain"
    ]

    var words = ['"Be yourself; everyone else is already taken."'
, '"So many books, so little time."' ,
 '"A friend is someone who knows all about you and still loves you."' ,
'"If you tell the truth, you dont have to remember anything."'];


do{
var num = Math.floor(Math.random()* name.length )
// console.log(name[num])
// console.log(words[num])
console.log(num)
document.getElementById("pp").innerHTML=words[num]
 document.getElementById("p2").innerHTML=name[num]
}
while(random === num.last);
num.last = Math.random();

// getNumber.last = random;

// console.log(name[num])
// console.log(words[num])
// document.getElementById("pp").innerHTML=words[num]
//  document.getElementById("p2").innerHTML=name[num]






// var num2 ;
// num2=Math.floor(Math.random()* name.length )
// if(num1=num2){
//     num2+=1
// }else{
//     console.log(name[num2])
//     console.log(words[num2])
//     document.getElementById("pp").innerHTML=words[num2]
//     document.getElementById("p2").innerHTML=name[num2] 
// }


}
// let x = 5

// console.log(x)


















